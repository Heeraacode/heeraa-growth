# 🚀 How to Deploy Your Content Engine (Super Simple Guide)

## What You're About to Do
1. Put your code on GitHub (like saving it to the cloud)
2. Connect GitHub to Vercel (a free website hosting service)
3. Get a link you can share with anyone!

---

## STEP 1: Get Your Computer Ready (One-Time Setup)

### 1.1 Install Node.js
Node.js is what runs JavaScript on your computer.

1. Go to: https://nodejs.org
2. Click the big green button that says "LTS" (the stable version)
3. Download and install it (just click Next, Next, Next...)
4. To check it worked, open Terminal (Mac) or Command Prompt (Windows) and type:
   ```
   node --version
   ```
   You should see something like `v20.10.0`

### 1.2 Install Git
Git is how you save code to GitHub.

1. Go to: https://git-scm.com/downloads
2. Download for your computer (Mac/Windows)
3. Install it (Next, Next, Next...)
4. To check it worked:
   ```
   git --version
   ```

### 1.3 Create a GitHub Account
1. Go to: https://github.com
2. Click "Sign Up"
3. Follow the steps (email, password, username)
4. Verify your email

### 1.4 Create a Vercel Account
1. Go to: https://vercel.com
2. Click "Sign Up"
3. Choose "Continue with GitHub" (easiest!)
4. Authorize Vercel to access your GitHub

---

## STEP 2: Create Your Project Folder

### 2.1 Create a folder on your computer

**On Mac:**
1. Open Terminal (press Cmd + Space, type "Terminal")
2. Type these commands one by one:
```bash
cd ~/Desktop
mkdir content-engine
cd content-engine
```

**On Windows:**
1. Open Command Prompt (press Windows key, type "cmd")
2. Type these commands one by one:
```bash
cd Desktop
mkdir content-engine
cd content-engine
```

### 2.2 Create the project
Still in Terminal/Command Prompt, type:
```bash
npm create vite@latest . -- --template react
```

It will ask you some questions:
- "Current directory is not empty" → type `y` and press Enter
- Select "React"
- Select "JavaScript"

Then type:
```bash
npm install
```
(This downloads all the stuff React needs. Takes 1-2 minutes.)

---

## STEP 3: Add Your Code

### 3.1 Open the folder
- **Mac:** In Terminal, type `open .` to open the folder
- **Windows:** In Command Prompt, type `explorer .`

### 3.2 Replace the App file
1. Download the `base44-content-engine-v7.jsx` file from Claude
2. Open the `src` folder in your project
3. DELETE the existing `App.jsx` file
4. RENAME `base44-content-engine-v7.jsx` to `App.jsx`
5. Move it into the `src` folder

### 3.3 Update the CSS
1. Open `src/index.css`
2. DELETE everything in it
3. Paste this instead:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
```

### 3.4 Install Tailwind CSS
Go back to Terminal/Command Prompt (make sure you're in the content-engine folder) and type:
```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

### 3.5 Configure Tailwind
1. Open the `tailwind.config.js` file that was just created
2. Replace EVERYTHING in it with:

```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

### 3.6 Test it locally
In Terminal/Command Prompt:
```bash
npm run dev
```

You should see something like:
```
  VITE v5.0.0  ready in 500 ms
  ➜  Local:   http://localhost:5173/
```

Open that link in your browser. You should see your Content Engine! 🎉

Press `Ctrl + C` to stop it when you're done testing.

---

## STEP 4: Put It on GitHub

### 4.1 Initialize Git
In Terminal/Command Prompt (in your project folder):
```bash
git init
git add .
git commit -m "First commit - Content Engine v7"
```

### 4.2 Create a GitHub Repository
1. Go to https://github.com
2. Click the green "New" button (or the + icon in top right)
3. Name it: `content-engine`
4. Keep it Public (or Private if you want)
5. DON'T check any boxes (no README, no gitignore)
6. Click "Create repository"

### 4.3 Push your code to GitHub
GitHub will show you some commands. Copy and run these (replace YOUR_USERNAME with your GitHub username):

```bash
git remote add origin https://github.com/YOUR_USERNAME/content-engine.git
git branch -M main
git push -u origin main
```

It might ask for your GitHub password. If it asks for a "token" instead:
1. Go to: https://github.com/settings/tokens
2. Click "Generate new token (classic)"
3. Give it a name like "my laptop"
4. Check the "repo" box
5. Click "Generate token"
6. Copy the token and paste it as your password

Refresh your GitHub page - you should see your code there! 🎉

---

## STEP 5: Deploy to Vercel (Get Your Link!)

### 5.1 Connect to Vercel
1. Go to https://vercel.com/dashboard
2. Click "Add New..." → "Project"
3. Find your `content-engine` repository
4. Click "Import"

### 5.2 Configure (just click deploy!)
Vercel is smart - it will detect it's a Vite/React project.
- You don't need to change anything
- Just click "Deploy"

### 5.3 Wait ~1 minute
Vercel will:
1. Download your code
2. Build it
3. Put it on the internet

### 5.4 Get your link! 🎉
When it says "Congratulations!", you'll see a link like:
```
https://content-engine-abc123.vercel.app
```

**That's your live website!** Share it with anyone!

---

## STEP 6: Make Updates in the Future

Whenever you change your code:

```bash
# In your project folder
git add .
git commit -m "Describe what you changed"
git push
```

Vercel will automatically detect the change and update your website in ~1 minute!

---

## 🎁 Bonus: Custom Domain (Optional)

If you want a custom URL like `contentengine.com`:

1. Buy a domain from Namecheap, Google Domains, or GoDaddy (~$10/year)
2. In Vercel, go to your project → Settings → Domains
3. Add your domain
4. Follow Vercel's instructions to update your domain's DNS settings

---

## ❓ Common Problems

### "npm not found"
You need to install Node.js (Step 1.1)

### "git not found"
You need to install Git (Step 1.2)

### "Permission denied"
On Mac, try adding `sudo` before the command:
```bash
sudo npm install
```

### The website looks broken
Make sure you:
1. Renamed the file to `App.jsx` (not `App.jsx.jsx`)
2. Put it in the `src` folder
3. Installed Tailwind CSS

### Changes not showing up
1. Make sure you saved the file
2. Make sure you ran `git push`
3. Wait 1-2 minutes for Vercel to rebuild

---

## 📁 Your Final Folder Structure

```
content-engine/
├── node_modules/       (auto-generated, lots of files)
├── public/
├── src/
│   ├── App.jsx         (YOUR CONTENT ENGINE CODE)
│   ├── index.css       (Tailwind CSS)
│   └── main.jsx        (don't touch this)
├── index.html
├── package.json
├── tailwind.config.js
├── postcss.config.js
└── vite.config.js
```

---

## 🎉 You Did It!

You now have:
- ✅ Your code saved on GitHub
- ✅ A live website anyone can visit
- ✅ Automatic updates when you change code

**Your link:** `https://content-engine-XXXXX.vercel.app`

Share it with your team! 🚀
